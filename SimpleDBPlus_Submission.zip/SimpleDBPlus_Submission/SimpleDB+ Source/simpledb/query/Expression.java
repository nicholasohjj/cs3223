package simpledb.query;

import java.util.function.Function;
import simpledb.record.*;

/**
 * The interface corresponding to SQL expressions.
 * @author Edward Sciore
 *
 */
public class Expression {
   private Constant val = null;
   private String fldname = null;
   
   public Expression(Constant val) {
      this.val = val;
   }
   
   public Expression(String fldname) {
      this.fldname = fldname;
   }
   
   /**
    * Evaluate the expression with respect to the
    * current record of the specified scan.
    * @param s the scan
    * @return the value of the expression, as a Constant
    */
   public Constant evaluate(Scan s) {
      return (val != null) ? val : s.getVal(fldname);
   }
   
   /**
    * Return true if the expression is a field reference.
    * @return true if the expression denotes a field
    */
   public boolean isFieldName() {
      return fldname != null;
   }
   
   /**
    * Return the constant corresponding to a constant expression,
    * or null if the expression does not
    * denote a constant.
    * @return the expression as a constant
    */
   public Constant asConstant() {
      return val;
   }
   
   /**
    * Return the field name corresponding to a constant expression,
    * or null if the expression does not
    * denote a field.
    * @return the expression as a field name
    */
   public String asFieldName() {
      return fldname;
   }
   
   /**
    * Determine if all of the fields mentioned in this expression
    * are contained in the specified schema.
    * @param sch the schema
    * @return true if all fields in the expression are in the schema
    */
   public boolean appliesTo(Schema sch) {
      return (val != null) ? true : sch.hasField(fldname);
   }
   
   public String toString() {
      if (val == null)
         return fldname;
      // quote string constants, so that the text can be parsed again (e.g. a view definition)
      return (val.asString() != null) ? "'" + val.asString() + "'" : val.toString();
   }

   /**
    * Returns a copy of this expression in which a field name
    * is replaced by the result of the specified function
    * (used to resolve field names to their qualified form).
    * @param rename maps a field name to its new name
    * @return the renamed expression
    */
   public Expression rename(Function<String,String> rename) {
      return (val != null) ? this : new Expression(rename.apply(fldname));
   }
}
