package simpledb.record;

import static java.sql.Types.*;
import simpledb.file.*;
import simpledb.tx.Transaction;

/**
 * Store a record at a given location in a block. 
 * @author Edward Sciore
 */
public class RecordPage {
   public static final int EMPTY = 0, USED = 1;
   private Transaction tx;
   private BlockId blk;
   private Layout layout;
   private boolean logged = true;

   public RecordPage(Transaction tx, BlockId blk, Layout layout) {
      this.tx = tx;
      this.blk = blk;
      this.layout = layout;
      tx.pin(blk);
   }

   /**
    * Creates a record page whose changes are logged only if
    * logged is true.  A temporary table is never recovered,
    * so its changes need not be logged.
    */
   public RecordPage(Transaction tx, BlockId blk, Layout layout, boolean logged) {
      this(tx, blk, layout);
      this.logged = logged;
   }

   /**
    * Return the integer value stored for the
    * specified field of a specified slot.
    * @param fldname the name of the field.
    * @return the integer stored in that field
    */
   public int getInt(int slot, String fldname) {
      int fldpos = offset(slot) + layout.offset(fldname);
      return tx.getInt(blk, fldpos);
   }

   /**
    * Return the string value stored for the
    * specified field of the specified slot.
    * @param fldname the name of the field.
    * @return the string stored in that field
    */
   public String getString(int slot, String fldname) {
      int fldpos = offset(slot) + layout.offset(fldname);
      return tx.getString(blk, fldpos);
   }

   /**
    * Store an integer at the specified field
    * of the specified slot.
    * @param fldname the name of the field
    * @param val the integer value stored in that field
    */
   /**
    * Return the double value stored for the
    * specified field of a specified slot.
    * @param fldname the name of the field.
    * @return the double stored in that field
    */
   public double getDouble(int slot, String fldname) {
      int fldpos = offset(slot) + layout.offset(fldname);
      return tx.getDouble(blk, fldpos);
   }

   /**
    * Store a double at the specified field
    * of the specified slot.
    * @param fldname the name of the field
    * @param val the double value stored in that field
    */
   public void setDouble(int slot, String fldname, double val) {
      int fldpos = offset(slot) + layout.offset(fldname);
      tx.setDouble(blk, fldpos, val, logged);
   }

   public void setInt(int slot, String fldname, int val) {
      int fldpos = offset(slot) + layout.offset(fldname);
      tx.setInt(blk, fldpos, val, logged);
   }

   /**
    * Store a string at the specified field
    * of the specified slot.
    * @param fldname the name of the field
    * @param val the string value stored in that field
    */
   public void setString(int slot, String fldname, String val) {
      int fldpos = offset(slot) + layout.offset(fldname);
      tx.setString(blk, fldpos, val, logged);
   }
   
   public void delete(int slot) {
      setFlag(slot, EMPTY);
   }
   
   /** Use the layout to format a new block of records.
    *  These values should not be logged 
    *  (because the old values are meaningless).
    */ 
   public void format() {
      int slot = 0;
      while (isValidSlot(slot)) {
         tx.setInt(blk, offset(slot), EMPTY, false); 
         Schema sch = layout.schema();
         for (String fldname : sch.fields()) {
            int fldpos = offset(slot) + layout.offset(fldname);
            if (sch.type(fldname) == INTEGER)
               tx.setInt(blk, fldpos, 0, false);
            else if (sch.type(fldname) == DOUBLE)
               tx.setDouble(blk, fldpos, 0.0, false);
            else
               tx.setString(blk, fldpos, "", false);
         }
         slot++;
      }
   }

   public int nextAfter(int slot) {
      return searchAfter(slot, USED);
   }
 
   public int insertAfter(int slot) {
      int newslot = searchAfter(slot, EMPTY);
      if (newslot >= 0)
         setFlag(newslot, USED);
      return newslot;
   }
  
   public BlockId block() {
      return blk;
   }
   
   // Private auxiliary methods
   
   /**
    * Set the record's empty/inuse flag.
    */
   private void setFlag(int slot, int flag) {
      tx.setInt(blk, offset(slot), flag, logged); 
   }

   private int searchAfter(int slot, int flag) {
      slot++;
      while (isValidSlot(slot)) {
         if (tx.getInt(blk, offset(slot)) == flag)
            return slot;
         slot++;
      }
      return -1;
   }

   private boolean isValidSlot(int slot) {
      return offset(slot+1) <= tx.blockSize();
   }

   private int offset(int slot) {
      return slot * layout.slotSize();
   }
}








